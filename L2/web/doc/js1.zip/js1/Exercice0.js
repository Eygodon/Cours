function display( message ) {
    console.log(message) ;

}
display("Hello World !");
display(2);
display(2<3);
display(new Date ()) ;